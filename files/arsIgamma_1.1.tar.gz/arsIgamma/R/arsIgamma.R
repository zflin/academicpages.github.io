
rpostgamma <- function(Sk, N, ss, n, d2){
  logSk = log(Sk)
  obj = new(arsIgamma, logSk, N, ss, n, d2)
  obj$update()
  tmp = obj$sampleIgamma()
  return(exp(tmp[,1]))
}












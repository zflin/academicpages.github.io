loadModule("arsIgamma_mod", TRUE)



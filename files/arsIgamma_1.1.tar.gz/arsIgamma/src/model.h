#ifndef MODELBASECLASS
#define MODELBASECLASS

#include <RcppArmadillo.h>
#include <Rcpp.h>
#include <cmath>
#include <vector>


using namespace Rcpp;
using namespace arma;
using namespace std;

class arsIgamma{
    
public:
    vec Sk, alphai, betai, samples, xcrosspoint;
    double ss, d2, alpha, beta, Mk;
    int N, n, nSk, npiece;
    mat Skm;

     
    arsIgamma(NumericVector, int, double, int, double);
    //void set_freq(double fff);
    //virtual ~varStar() {}

    double uk(double);
	double lk(double);
	double h(double);

	void update();


	double gkSample();


	vec sampleIgamma();
};


#endif //MODELBASECLASS

#include "model.h"


RCPP_MODULE(arsIgamma_mod){
    class_<arsIgamma>("arsIgamma")
    .constructor<NumericVector, int, double, int, double>()
    .field("Sk", &arsIgamma::Sk)
    .field("N", &arsIgamma::N)
    .field("n", &arsIgamma::n)
    .field("ss", &arsIgamma::ss)
    .field("d2", &arsIgamma::d2)
    .field("samples", &arsIgamma::samples)
    .field("xcrosspoint", &arsIgamma::xcrosspoint)
    .field("alpha", &arsIgamma::alpha)
    .field("beta", &arsIgamma::beta)
    .field("nSk", &arsIgamma::nSk)
    .field("npiece", &arsIgamma::npiece)
    .field("betai", &arsIgamma::betai)
    .field("alphai", &arsIgamma::alphai)
    .field("Mk", &arsIgamma::Mk)
    .field("Skm", &arsIgamma::Skm)

    .method("h", &arsIgamma::h)
    .method("uk", &arsIgamma::uk)
    .method("lk", &arsIgamma::lk)
    .method("update", &arsIgamma::update)
    .method("gkSample", &arsIgamma::gkSample)
    .method("sampleIgamma", &arsIgamma::sampleIgamma)
    ;
    
}

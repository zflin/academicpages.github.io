#include "model.h"


arsIgamma::arsIgamma(NumericVector Sk_, int N_, double ss_, int n_, double d2_){

	Sk = unique(vec(Sk_));
	N = N_;
	ss = ss_;
	n = n_;
	d2 = d2_;

	alpha = 0.5*(n + 1.0/d2);
	beta = ss/2.0;

}

double arsIgamma::h(double x){
	return(-alpha*x - beta*exp(-x));
}

void arsIgamma::update(){
	arsIgamma::nSk = arsIgamma::Sk.n_elem;
	arsIgamma::npiece = (nSk+1-4)+2;
	Skm = mat(2*npiece,6, fill::zeros);

	alphai = vec(nSk-1, fill::zeros);
	betai = vec(nSk-1, fill::zeros);

	for (int i = 0; i < nSk-1; ++i)
	{
		alphai[i] = (h(Sk[i])-h(Sk[i+1])) / (Sk[i]-Sk[i+1]);
		betai[i] = -(Sk[i+1]*h(Sk[i])-Sk[i]*h(Sk[i+1])) / (Sk[i]-Sk[i+1]);
	}

	xcrosspoint = vec(nSk-3, fill::zeros);
	for (int i = 0; i < nSk-3; ++i)
	{
		xcrosspoint[i] = -(betai[i]-betai[i+2]) / (alphai[i] - alphai[i+2]);
	}
	for (int i = 0; i < npiece; ++i)
	{
		if (i==0)
		{
			Skm(i,0) = -INFINITY;
			Skm(i,1) = Sk[0];
			Skm(i,2) = alphai[0];
			Skm(i,3) = betai[0];
			Skm(i,4) = (exp(Skm(i,2)*Skm(i,1)+Skm(i,3)) - exp(Skm(i,2)*Skm(i,0)+Skm(i,3)))/Skm(i,2);
			Skm(i+1,0) = Sk[0];
			Skm(i+1,1) = Sk[1];
			Skm(i+1,2) = alphai[1];
			Skm(i+1,3) = betai[1];
			Skm(i+1,4) = (exp(Skm(i+1,2)*Skm(i+1,1)+Skm(i+1,3)) - exp(Skm(i+1,2)*Skm(i+1,0)+Skm(i+1,3)))/Skm(i+1,2);
			Skm(i+1,5) = Skm(i,4);
			continue;
		}
		if (i==npiece-1)
		{
			Skm(2*i,0) = Sk[nSk-2];
			Skm(2*i,1) = Sk[nSk-1];
			Skm(2*i,2) = alphai[nSk-3];
			Skm(2*i,3) = betai[nSk-3];
			Skm(2*i,4) = (exp(Skm(2*i,2)*Skm(2*i,1)+Skm(2*i,3)) - exp(Skm(2*i,2)*Skm(2*i,0)+Skm(2*i,3)))/Skm(2*i,2);
			Skm(2*i,5) = Skm(2*i-1,5) + Skm(2*i-1,4);
			Skm(2*i+1,0) = Sk[nSk-1];
			Skm(2*i+1,1) = INFINITY;
			Skm(2*i+1,2) = alphai[nSk-2];
			Skm(2*i+1,3) = betai[nSk-2];
			Skm(2*i+1,4) = (exp(Skm(2*i+1,2)*Skm(2*i+1,1)+Skm(2*i+1,3)) - exp(Skm(2*i+1,2)*Skm(2*i+1,0)+Skm(2*i+1,3)))/Skm(2*i+1,2);
			Skm(2*i+1,5) = Skm(2*i,5) + Skm(2*i,4);
			continue;
		}
		Skm(2*i,0) = Sk[i];
		Skm(2*i,1) = xcrosspoint[i-1];
		Skm(2*i,2) = alphai[i-1];
		Skm(2*i,3) = betai[i-1];
		Skm(2*i,4) = (exp(Skm(2*i,2)*Skm(2*i,1)+Skm(2*i,3)) - exp(Skm(2*i,2)*Skm(2*i,0)+Skm(2*i,3)))/Skm(2*i,2);
		Skm(2*i,5) = Skm(2*i-1,5) + Skm(2*i-1,4);
		Skm(2*i+1,0) = xcrosspoint[i-1];
		Skm(2*i+1,1) = Sk[i+1];
		Skm(2*i+1,2) = alphai[i+1];
		Skm(2*i+1,3) = betai[i+1];
		Skm(2*i+1,4) = (exp(Skm(2*i+1,2)*Skm(2*i+1,1)+Skm(2*i+1,3)) - exp(Skm(2*i+1,2)*Skm(2*i+1,0)+Skm(2*i+1,3)))/Skm(2*i+1,2);
		Skm(2*i+1,5) = Skm(2*i,5) + Skm(2*i,4);
	}

	Mk = Skm(2*npiece-1,5) + Skm(2*npiece-1,4);

}


double arsIgamma::uk(double x){
	int kk = sum(x>Sk);
	if(kk < 2){
		return(alphai[kk]*x+betai[kk]);
	}
	if(kk > nSk-2){
		return(alphai[kk-2]*x+betai[kk-2]);
	}
	return(min(alphai[kk]*x+betai[kk], alphai[kk-2]*x+betai[kk-2]));
}

double arsIgamma::lk(double x){
	int kk = sum(x>Sk);
	if((kk==0)|(kk==nSk)){
		return(-INFINITY);
	}else{
		return(alphai[kk-1]*x+betai[kk-1]);
	}
}

double arsIgamma::gkSample(){
	double ru = randu(1)[0]*Mk;
	//cout << ru << "\n";
	vec csum = Skm.col(5);
	int kk = sum(ru>=csum)-1;
	//cout << kk << "\n";
	ru = ru - csum[kk];
	double tmp = (log(ru*Skm(kk,2) + exp(Skm(kk,2)*Skm(kk,0)+Skm(kk,3))) - Skm(kk,3)) / Skm(kk,2);
	return(tmp);
}




vec arsIgamma::sampleIgamma(){

	samples = vec(N, fill::zeros);
	

	for (int j = 0; j < N; ++j)
	{

		bool flag = 1;
		while(flag){
			double rgk = gkSample();
			double ru = randu(1)[0];
			if(ru < exp(lk(rgk)-uk(rgk))){
				flag = 0;
				samples[j] = rgk;
			}else if (ru < exp(h(rgk)-uk(rgk))){
				Sk.resize(nSk+1);
				Sk[nSk] = rgk;
				flag = 0;
				
			}
			if(flag==0){
				if(nSk<500){
					Sk.resize(nSk+1);
					Sk[nSk] = rgk;
					Sk = unique(Sk);
					update();
				}
				samples[j] = rgk;
			}
		}
		

	}

	return(samples);


}







